import { randomUUID } from "node:crypto";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import {
  companies,
  createDb,
  documents,
  goalBriefs,
  goalRuns,
  goals,
  issueWorkProducts,
  issues,
  recipes,
  recipeVersions,
  resourceLeases,
} from "@paperclipai/db";
import {
  getEmbeddedPostgresTestSupport,
  startEmbeddedPostgresTestDatabase,
} from "./helpers/embedded-postgres.js";
import { goalLoopService } from "../services/goal-loop.ts";

const embeddedPostgresSupport = await getEmbeddedPostgresTestSupport();
const describeEmbeddedPostgres = embeddedPostgresSupport.supported ? describe : describe.skip;

if (!embeddedPostgresSupport.supported) {
  console.warn(
    `Skipping embedded Postgres goal-loop service tests on this host: ${embeddedPostgresSupport.reason ?? "unsupported environment"}`,
  );
}

describeEmbeddedPostgres("goalLoopService resource lease handling", () => {
  let db!: ReturnType<typeof createDb>;
  let svc!: ReturnType<typeof goalLoopService>;
  let tempDb: Awaited<ReturnType<typeof startEmbeddedPostgresTestDatabase>> | null = null;

  beforeAll(async () => {
    tempDb = await startEmbeddedPostgresTestDatabase("paperclip-goal-loop-service-");
    db = createDb(tempDb.connectionString);
    svc = goalLoopService(db);
  }, 20_000);

  afterEach(async () => {
    await db.delete(resourceLeases);
    await db.delete(issueWorkProducts);
    await db.delete(issues);
    await db.delete(goalRuns);
    await db.delete(goalBriefs);
    await db.delete(recipeVersions);
    await db.delete(recipes);
    await db.delete(documents);
    await db.delete(goals);
    await db.delete(companies);
  });

  afterAll(async () => {
    await tempDb?.cleanup();
  });

  it("queues conflicting production runs behind an active exclusive-write lease", async () => {
    const companyId = randomUUID();
    const goalId = randomUUID();
    const recipeId = randomUUID();
    const recipeVersionId = randomUUID();
    const briefDocumentId = randomUUID();

    await db.insert(companies).values({
      id: companyId,
      name: "Paperclip",
      issuePrefix: `GL${companyId.replace(/-/g, "").slice(0, 6).toUpperCase()}`,
      requireBoardApprovalForNewAgents: false,
      defaultGoalMode: "goal_loop",
    });

    await db.insert(goals).values({
      id: goalId,
      companyId,
      title: "Repair the website",
      description: "Goal-loop lease test",
      level: "company",
      status: "active",
      mode: "goal_loop",
    });

    await db.insert(documents).values({
      id: briefDocumentId,
      companyId,
      title: "Goal brief",
      latestBody: "Repair the homepage and publish the changes.",
      latestRevisionNumber: 1,
      createdByUserId: "board-user",
      updatedByUserId: "board-user",
    });

    await db.insert(recipes).values({
      id: recipeId,
      companyId,
      slug: "website-repair-test",
      name: "Website repair",
      source: "company",
      status: "active",
    });

    await db.insert(recipeVersions).values({
      id: recipeVersionId,
      companyId,
      recipeId,
      version: 1,
      title: "Website repair v1",
      definition: {},
      requiredSkillKeys: [],
      outputType: "website",
      createsPrimaryOutput: true,
    });

    await db.insert(goalBriefs).values({
      companyId,
      goalId,
      documentId: briefDocumentId,
      status: "ready",
      recipeId,
      recipeVersionId,
      finishLine: "Homepage repaired",
      finishCriteria: [{ id: "finish", label: "Publish the fix" }],
      accessChecklist: [{ key: "site", label: "Production access", status: "ready" }],
      launchChecklist: [],
    });

    const firstRun = await svc.executeGoalRun(
      goalId,
      { requestedPhase: "production" },
      { userId: "board-user" },
    );

    expect(firstRun.run.status).toBe("running");
    expect(firstRun.run.currentPhase).toBe("production");
    expect(firstRun.issue?.id).toBeTruthy();

    const blockedRun = await svc.executeGoalRun(
      goalId,
      { requestedPhase: "production", force: true },
      { userId: "board-user" },
    );

    expect(blockedRun.issue).toBeNull();
    expect(blockedRun.run.status).toBe("queued");
    expect(blockedRun.run.currentPhase).toBe("production");
    expect(blockedRun.run.failureSummary).toContain("Waiting for resource lease");

    const leases = await svc.listResourceLeases(companyId, {
      goalId,
      status: "active",
    });
    expect(leases).toHaveLength(1);
    expect(leases[0]).toMatchObject({
      goalRunId: firstRun.run.id,
      mode: "exclusive_write",
      status: "active",
    });
  });

  it("blocks verification-phase completion until a primary output is verified", async () => {
    const companyId = randomUUID();
    const goalId = randomUUID();
    const recipeId = randomUUID();
    const recipeVersionId = randomUUID();
    const briefDocumentId = randomUUID();

    await db.insert(companies).values({
      id: companyId,
      name: "Paperclip",
      issuePrefix: `GV${companyId.replace(/-/g, "").slice(0, 6).toUpperCase()}`,
      requireBoardApprovalForNewAgents: false,
      defaultGoalMode: "goal_loop",
    });

    await db.insert(goals).values({
      id: goalId,
      companyId,
      title: "Verify a shipped output",
      description: "Goal-loop proof gate test",
      level: "company",
      status: "active",
      mode: "goal_loop",
    });

    await db.insert(documents).values({
      id: briefDocumentId,
      companyId,
      title: "Goal brief",
      latestBody: "Ship and verify the output.",
      latestRevisionNumber: 1,
      createdByUserId: "board-user",
      updatedByUserId: "board-user",
    });

    await db.insert(recipes).values({
      id: recipeId,
      companyId,
      slug: "verification-test",
      name: "Verification recipe",
      source: "company",
      status: "active",
    });

    await db.insert(recipeVersions).values({
      id: recipeVersionId,
      companyId,
      recipeId,
      version: 1,
      title: "Verification v1",
      definition: {},
      requiredSkillKeys: [],
      outputType: "document",
      createsPrimaryOutput: true,
    });

    await db.insert(goalBriefs).values({
      companyId,
      goalId,
      documentId: briefDocumentId,
      status: "ready",
      recipeId,
      recipeVersionId,
      finishLine: "Output verified",
      finishCriteria: [{ id: "finish", label: "Verify the output" }],
      accessChecklist: [{ key: "site", label: "Production access", status: "ready" }],
      launchChecklist: [],
    });

    const run = await svc.executeGoalRun(
      goalId,
      { requestedPhase: "verification" },
      { userId: "board-user" },
    );

    expect(run.issue?.id).toBeTruthy();

    await expect(svc.validateGoalRunIssueStatusChange(run.issue!.id, "done")).rejects.toThrow(
      "Verification phase cannot complete until a primary output is verified",
    );

    await db.insert(issueWorkProducts).values({
      companyId,
      issueId: run.issue!.id,
      goalId,
      goalRunId: run.run.id,
      type: "document",
      provider: "manual",
      title: "Published artifact",
      status: "ready_for_review",
      outputType: "document",
      outputStatus: "verified",
      isPrimary: true,
      verifiedAt: new Date(),
    });

    await expect(svc.validateGoalRunIssueStatusChange(run.issue!.id, "done")).resolves.toBeUndefined();
  });
});
